package by.epam.task4.dao.user;

import by.epam.task4.dao.AbstractDAO;
import by.epam.task4.entity.User;

public interface UserDAO extends AbstractDAO<User> {
}
