package by.epam.task4.dao;

import by.epam.task4.entity.Entity;

public interface AbstractDAO<T extends Entity> {
}
