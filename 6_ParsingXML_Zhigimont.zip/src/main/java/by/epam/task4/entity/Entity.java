package by.epam.task4.entity;

import java.io.Serializable;

public abstract class Entity implements Serializable, Cloneable{
}
